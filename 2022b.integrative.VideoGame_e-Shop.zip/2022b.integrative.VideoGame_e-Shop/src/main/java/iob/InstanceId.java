package iob;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;

public class InstanceId {
	
	@Value("${spring.application.name:Default 2022b.Amit.Levy}")
	private String domain = "2022b.Amit.Levy";
	private String id;
	
	public InstanceId() {
		this.id = UUID.randomUUID().toString();
		this.domain = "2022b.Amit.Levy";
	}

	public InstanceId(String id) {
		this.id = id;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
