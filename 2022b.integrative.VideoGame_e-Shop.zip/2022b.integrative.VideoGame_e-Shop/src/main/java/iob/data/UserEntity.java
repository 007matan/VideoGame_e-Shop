package iob.data;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import org.springframework.data.annotation.Id;



import org.springframework.data.mongodb.core.mapping.Document;

import iob.UserId;

@Document
public class UserEntity {
	private UserId userId;
	private UserRole role;
	private String username;
	private String avatar;

	public UserEntity() {
		this.userId = new UserId();
	}

	public UserEntity(String userEmail, UserRole role, String username, String avatar) {
		this.userId = new UserId(userEmail);
		this.role = role;
		this.username = username;
		this.avatar = avatar;
	}
	
	@Id
	public UserId getUId() {
		return userId;
	}
	
	
	public void setUId(UserId uId) {
		userId = uId;
	}

	@Enumerated(EnumType.STRING)
	public UserRole getRole() {
		return role;
	}

	public void setRole(UserRole role) {
		this.role = role;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	
	@Override
	public String toString() {
		return "UserEntity [userId=" + userId + ", role=" + role + ", username=" + username + ", avatar=" + avatar
				+ "]";
	}
}
