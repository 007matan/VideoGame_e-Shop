package iob.data;

import java.util.Date;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import iob.ActivityId;
import iob.InstanceId;
import iob.UserId;

@Document
public class ActivityEntity {
	private ActivityId id;
	private String type;
	private InstanceId instanceId;
	private Date createdTimestamp;
	private UserId invokedBy;
	// to save email and domain of the user

	public ActivityEntity() {
	}

	/**
	 * 
	 * @param activityId
	 * @param type
	 * @param instance
	 * @param createdTimestamp
	 * @param invokedBy
	 */
	public ActivityEntity(ActivityId activityId, String type, InstanceId instanceId, UserId invokedBy) {
		this.id = activityId;
		this.type = type;
		this.instanceId = instanceId;
		this.createdTimestamp = new Date();
		this.invokedBy = invokedBy;
	}

	@Id
	public String getActivityId() {
		return id.getId();
	}

	public void setActivityId(ActivityId activityId) {
		this.id = activityId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getInstance() {
		return instanceId.getId();
	}

	public void setInstance(InstanceId instance) {
		this.instanceId = instance;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public UserId getInvokedBy() {
		return invokedBy;
	}

	public void setInvokedBy(UserId invokedBy) {
		this.invokedBy = invokedBy;
	}

	
}
