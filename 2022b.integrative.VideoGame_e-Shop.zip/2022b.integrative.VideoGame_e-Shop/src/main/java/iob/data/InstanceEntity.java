package iob.data;

import java.util.Date;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import iob.InstanceId;
import iob.Location;
import iob.UserId;

@Document
public class InstanceEntity {
	private InstanceId id;
	private String type;
	private String name;
	private boolean active;
	private Date createdTimestamp;
	private UserId createdBy;
	private Location location;
	
	public InstanceEntity(){
		id = new InstanceId();
	}
	
	/**
	 * 
	 * @param instanceId
	 * @param type
	 * @param name
	 * @param active
	 * @param createdTimestamp
	 * @param createdBy
	 * @param location
	 */
	public InstanceEntity(InstanceId instanceId, String type, String name, boolean active,UserId createdBy, Location location) {
		super();
		this.id = instanceId;
		this.type = type;
		this.name = name;
		this.active = active;
		this.createdTimestamp = new Date();
		this.createdBy = createdBy;
		this.location = location;
	}
	
	@Id
	public InstanceId getInstanceId() {
		return id;
	}

	public void setInstanceId(InstanceId instanceId) {
		this.id = instanceId;
	}
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public boolean getActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	
	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	
	
	public UserId getCreatedBy() {
		return createdBy;
	}
	
	
	public void setCreatedBy(UserId createdBy) {
		this.createdBy = createdBy;
	}
	
	public Location getLocation() {
		return location;
	}
	
	public void setLocation(Location location) {
		this.location = location;
	}
	
	
}
