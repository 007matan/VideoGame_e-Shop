package iob.logic;

import java.util.List;

import iob.boundary.InstanceBoundary;

public interface EnhancedInstancesService extends InstancesService {
	List<InstanceBoundary> getSpecificInstanceByName(String userDomain,String userEmail,String name,int size,int page);
	List<InstanceBoundary> getSpecificInstanceByType(String userDomain,String userEmail,String type,int size,int page);
	List<InstanceBoundary> getSpecificInstanceByLocation(String userDomain,String userEmail,double lat,double lon,double distance,int size,int page);
	
	void updateInstance(String instanceDomain ,String instanceID,String userDomain,String userEmail,InstanceBoundary update);
	InstanceBoundary getSpecificInstance(String instanceDomain ,String instanceID,String userDomain,String userEmail);
	List<InstanceBoundary> getAllInstances(String userDomain,String userEmail,int size,int page);
	
	void deleteAllInstances(String userDomain,String userEmail);
}
