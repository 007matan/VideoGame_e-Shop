package iob.logic;

import java.util.List;

import iob.boundary.UserBoundary;

public interface EnhancedUsersService extends UsersService {
	void deleteAllUsers(String userDomain,String userEmail);
	List<UserBoundary> getAllUsers(String userDomain,String userEmail,int size,int page);
	
	
}	
