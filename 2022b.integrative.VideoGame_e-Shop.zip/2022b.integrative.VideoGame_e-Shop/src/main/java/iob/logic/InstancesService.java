package iob.logic;

import java.util.List;

import iob.boundary.InstanceBoundary;

public interface InstancesService {
	InstanceBoundary createInstance(InstanceBoundary instance);
	@Deprecated
	void updateInstance(String instanceDomain ,String instanceID,InstanceBoundary update );
	@Deprecated
	InstanceBoundary getSpecificInstance(String instanceDomain ,String instanceID);
	@Deprecated
	List<InstanceBoundary> getAllInstances();
	@Deprecated
	void deleteAllInstances();
}
