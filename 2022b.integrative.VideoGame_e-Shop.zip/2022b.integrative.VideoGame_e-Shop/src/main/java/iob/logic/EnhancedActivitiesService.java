package iob.logic;

import java.util.List;

import iob.boundary.ActivityBoundary;

public interface EnhancedActivitiesService extends ActivitiesService {
	List<ActivityBoundary> getAllActivities(String userDomain,String userEmail,int size,int page);
	void deleteAllActivities(String userDomain,String userEmail);
}
