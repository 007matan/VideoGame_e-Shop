package iob.logic;

import java.util.List;

import iob.boundary.ActivityBoundary;

public interface ActivitiesService {
	Object invokeActivity(ActivityBoundary activity);
	@Deprecated
	List<ActivityBoundary> getAllActivities();
	@Deprecated
	void deleteAllActivities();
}
