package iob.logic;

import java.util.List;

import iob.boundary.NewUserBoundary;
import iob.boundary.UserBoundary;

public interface UsersService {
	UserBoundary createUser(NewUserBoundary user);
	UserBoundary login(String userDomain,String userEmail );
	UserBoundary updateUser(String userDomain,String userEmail,UserBoundary update);
	@Deprecated
	List<UserBoundary> getAllUsers();
	@Deprecated
	void deleteAllUsers();
}
