package iob.doa;

import org.springframework.data.mongodb.repository.MongoRepository;

import iob.data.ActivityEntity;

public interface ActivitiesDao  extends MongoRepository<ActivityEntity, String> {
	
}
