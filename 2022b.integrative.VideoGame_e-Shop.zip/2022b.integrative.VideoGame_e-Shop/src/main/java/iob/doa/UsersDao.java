package iob.doa;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;

import iob.UserId;
import iob.data.UserEntity;


public interface UsersDao extends MongoRepository<UserEntity, String>  {
	

	public List<UserEntity> findByuserId(
			@Param("UserId") UserId UId,
			 Pageable pageable);

}
