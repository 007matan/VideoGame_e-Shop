package iob.doa;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;

import iob.data.InstanceEntity;

public interface InstancesDao extends MongoRepository<InstanceEntity, String> {
	
	public List<InstanceEntity> findInstanceByName(
			@Param("name") String name,
			Pageable pageable
			);
	
	public List<InstanceEntity> findInstanceByType(
			@Param("type") String type,
			Pageable pageable
			);
	
	public List<InstanceEntity> findInstanceByLocation(
			@Param("lat") double lat,
			@Param("lon") double lon,
			@Param("distance") double distance,
			Pageable pageable
			);
	
	
}
