package iob.converters;

import java.util.Date;

import org.springframework.stereotype.Component;

import iob.ActivityId;
import iob.InstanceId;
import iob.UserId;
import iob.boundary.ActivityBoundary;
import iob.boundary.UserBoundary;
import iob.data.ActivityEntity;
import iob.data.UserEntity;

@Component
public class ActivityConverter {
	UserConverter converter = new UserConverter();

	public ActivityEntity toEntity(ActivityBoundary boundary) {
		ActivityEntity entity = new ActivityEntity();

		entity.setActivityId(boundary.getActivityId());

		if (boundary.getCreatedTimestamp() == null)
			entity.setCreatedTimestamp((new Date()));
		else
			entity.setCreatedTimestamp(boundary.getCreatedTimestamp());
		
		entity.setInstance(boundary.getInstanceId());
		
		if (boundary.getInvokedBy() == null)
			entity.setInvokedBy(new UserId("default@mail.com"));
		else 
			entity.setInvokedBy(boundary.getInvokedBy());
		
		
		if (boundary.getType() == null) 
			entity.setType("No Type");
		 else 
			entity.setType(boundary.getType());
		
		return entity;
	}

	public ActivityBoundary toBoundary(ActivityEntity entity) {
		ActivityBoundary boundary = new ActivityBoundary();
		
		boundary.setActivityId(new ActivityId(entity.getActivityId()));
		
		if(entity.getCreatedTimestamp() == null)
			boundary.setCreatedTimestamp(new Date());
		else
			boundary.setCreatedTimestamp(entity.getCreatedTimestamp());
		
		
		boundary.setInstanceId(new InstanceId(entity.getInstance()));
		
		if(entity.getInvokedBy() == null)
			boundary.setInvokedBy(new UserId("default@mail.com"));
		else 
			boundary.setInvokedBy(entity.getInvokedBy());
		
		
		if(entity.getType() == null) 
			boundary.setType("No Type");
		else 
			boundary.setType(entity.getType());
		

		return boundary;
	}

}
