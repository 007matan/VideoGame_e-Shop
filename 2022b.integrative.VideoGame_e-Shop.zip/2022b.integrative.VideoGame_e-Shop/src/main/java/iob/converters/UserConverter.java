package iob.converters;

import org.springframework.stereotype.Component;

import iob.UserId;
import iob.Jpa.NotFoundException;
import iob.boundary.NewUserBoundary;
import iob.boundary.UserBoundary;
import iob.data.UserEntity;
import iob.data.UserRole;

@Component
public class UserConverter {

	public UserEntity toEntity(UserBoundary boundary) {
		UserEntity entity = new UserEntity();
		System.out.println(boundary.toString());
		if (boundary.getAvatar() == null || boundary.getAvatar().isEmpty())
			entity.setAvatar("No Avatar");
		else
			entity.setAvatar(boundary.getAvatar());
		entity.setRole(boundary.getRole());

		String domain = boundary.getUserId().getDomain();
		if (domain == null || domain.isEmpty())
			entity.getUId().setDomain(domain);
		else
			entity.getUId().setDomain(domain);

		String email = boundary.getUserId().getUserEmail();
		if (email == null || email.isEmpty())
			entity.getUId().setUserEmail("No Email");
		else
			entity.getUId().setUserEmail(email);

		String username = boundary.getUsername();
		if (username == null || username.isEmpty())
			entity.setUsername("No username");
		else
			entity.setUsername(username);

		return entity;

	}

	public UserBoundary toBoundary(UserEntity entity) {
		UserBoundary boundary = new UserBoundary();
		
		String email = entity.getUId().getUserEmail();
		boundary.setAvatar(entity.getAvatar());
		boundary.setRole(entity.getRole());
		boundary.setUsername(entity.getUsername());
		boundary.setUserId(entity.getUId());
		
		return boundary;
	}

	public UserBoundary toUserBoundary(NewUserBoundary newUser) {

		UserId UId = new UserId(newUser.getEmail());

		return new UserBoundary(UId, newUser.getRole(), newUser.getUsername(), newUser.getAvatar());

	}

	public NewUserBoundary toNewUserBoundary(UserBoundary user) {
		if (user != null)
			return new NewUserBoundary(user.getUserId().getUserEmail(), user.getRole(), user.getUsername(),
					user.getAvatar());

		throw new NotFoundException("Null user");

	}

}
