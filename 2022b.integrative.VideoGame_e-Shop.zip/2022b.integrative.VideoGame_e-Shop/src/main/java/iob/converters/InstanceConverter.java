package iob.converters;

import java.util.Date;

import org.springframework.stereotype.Component;

import iob.InstanceId;
import iob.Location;
import iob.UserId;
import iob.boundary.InstanceBoundary;
import iob.boundary.NewUserBoundary;
import iob.data.InstanceEntity;

@Component
public class InstanceConverter {
	UserConverter converter = new UserConverter();

	public InstanceEntity toEntity(InstanceBoundary boundary) {
		InstanceEntity entity = new InstanceEntity();

		if (boundary.getActive() == null)
			entity.setActive(false);
		else
			entity.setActive(boundary.getActive());
		
		entity.setCreatedBy(boundary.getCreatedBy());
		entity.setCreatedTimestamp(new Date());
		entity.setInstanceId(boundary.getInstanceId());

		if (boundary.getLocation() == null)
			entity.setLocation(new Location(0, 0));
		else
			entity.setLocation(boundary.getLocation());

		String name = boundary.getName();
		if (name == null || name.isEmpty())
			boundary.setName("No Name");
		else
			boundary.setName(name);

		String type = boundary.getType();
		if (type == null || type.isEmpty())
			entity.setType("No Type");
		else
			entity.setType(type);

		return entity;
	}

	public InstanceBoundary toBoundary(InstanceEntity entity) {
		InstanceBoundary boundary = new InstanceBoundary();

		if (boundary.getActive() == null)
			boundary.setActive(false);
		else
			boundary.setActive(entity.getActive());

		if (entity.getCreatedBy() != null)
			boundary.setCreatedBy(entity.getCreatedBy());
		else {
			boundary.setCreatedBy(new UserId("default@mail.com"));
		}

		if (entity.getCreatedTimestamp() == null)
			boundary.setCreatedTimestamp(new Date());
		else
			boundary.setCreatedTimestamp(entity.getCreatedTimestamp());

		boundary.setCreatedTimestamp(entity.getCreatedTimestamp());

		boundary.setInstanceId(new InstanceId(entity.getInstanceId().getId()));

		if (entity.getLocation() == null)
			boundary.setLocation(new Location(0, 0));
		else
			boundary.setLocation(entity.getLocation());

		String name = entity.getName();
		if (name == null || name.isEmpty())
			boundary.setName("No Name");
		else
			boundary.setName(name);

		String type = entity.getType();
		if (type == null || type.isEmpty())
			boundary.setType("No Type");
		else
			boundary.setType(type);

		return boundary;
	}

}
