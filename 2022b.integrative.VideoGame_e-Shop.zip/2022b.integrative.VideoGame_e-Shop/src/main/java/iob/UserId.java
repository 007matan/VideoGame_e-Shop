package iob;

import org.springframework.beans.factory.annotation.Value;

public class UserId{
	@Value("${spring.application.name:Default 2022b.Amit.Levy}")
	private String domain = "2022b.Amit.Levy";
	private String userEmail;
	
	public UserId( String userEmail) {
		this.userEmail = userEmail;
		this.domain = "2022b.Amit.Levy";
	}

	public UserId() {
		
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	@Override
	public String toString() {
		return "UserId [domain=" + domain + ", userEmail=" + userEmail + "]";
	}
	
	
	
	
}
