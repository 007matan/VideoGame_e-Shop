package iob.boundary;

import java.util.Date;
import java.util.Map;

import iob.ActivityId;
import iob.InstanceId;
import iob.UserId;



public class ActivityBoundary {
	private ActivityId activityId;
	private String type;
	private InstanceId instanceId;
	private Date createdTimestamp;
	private UserId invokedBy;
	private Map<String,Object> ActivityAttributes;

	public ActivityBoundary() {
		activityId = new ActivityId();
	}

	public ActivityBoundary(ActivityId activityId, String type, InstanceId instanceId, Date createdTimestamp,
			UserId invokedBy, Map<String, Object> activityAttributes) {
		super();
		this.activityId = activityId;
		this.type = type;
		this.instanceId = instanceId;
		this.createdTimestamp = createdTimestamp;
		this.invokedBy = invokedBy;
		ActivityAttributes = activityAttributes;
	}

	public ActivityId getActivityId() {
		return activityId;
	}

	public void setActivityId(ActivityId activityId) {
		this.activityId = activityId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public InstanceId getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(InstanceId instanceId) {
		this.instanceId = instanceId;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public UserId getInvokedBy() {
		return invokedBy;
	}

	public void setInvokedBy(UserId invokedBy) {
		this.invokedBy = invokedBy;
	}

	public Map<String, Object> getActivityAttributes() {
		return ActivityAttributes;
	}

	public void setActivityAttributes(Map<String, Object> activityAttributes) {
		ActivityAttributes = activityAttributes;
	}

	@Override
	public String toString() {
		return "ActivityBoundary [activityId=" + activityId + ", type=" + type + ", instanceId=" + instanceId
				+ ", createdTimestamp=" + createdTimestamp + ", invokedBy=" + invokedBy + ", ActivityAttributes="
				+ ActivityAttributes + "]";
	}
	
	
	
	
	
}
