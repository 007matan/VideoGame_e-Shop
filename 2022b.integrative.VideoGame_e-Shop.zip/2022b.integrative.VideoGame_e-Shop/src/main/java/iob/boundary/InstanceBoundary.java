package iob.boundary;

import java.util.Date;
import java.util.Map;
import java.util.UUID;

import iob.InstanceId;
import iob.Location;
import iob.UserId;

public class InstanceBoundary {
	private InstanceId instanceId;
	private String type;
	private String name;
	private Boolean active;
	private Date createdTimestamp;
	private UserId createdBy;
	private Location location;
	private Map<String,Object> instanceAttributes;

	public InstanceBoundary() {

	}

	/**
	 * @param type
	 * @param name
	 * @param active
	 * @param createdTimestamp
	 * @param createdBy        - UserID
	 */
	public InstanceBoundary(String type, String name, Boolean active, Date createdTimestamp, UserId createdBy,
			Location location) {
		this.instanceId = new InstanceId();
		this.type = type;
		this.name = name;
		this.active = active;

		if (createdTimestamp == null)
			this.createdTimestamp = new Date();
		else
			this.createdTimestamp = createdTimestamp;

		this.createdBy = createdBy;
		this.location = location;
	}

	public InstanceId getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(InstanceId instanceId) {
		this.instanceId = instanceId;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public UserId getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserId createdBy) {
		this.createdBy = createdBy;
	}
	
	public Map<String, Object> getInstanceAttributes() {
		return instanceAttributes;
	}

	public void setInstanceAttributes(Map<String, Object> instanceAttributes) {
		this.instanceAttributes = instanceAttributes;
	}

	@Override
	public String toString() {
		return "InstanceBoundary [instanceId=" + instanceId + ", type=" + type + ", name=" + name + ", active=" + active
				+ ", createdTimestamp=" + createdTimestamp + ", createdBy=" + createdBy + ", location=" + location
				+ "]";
	}
	/*
	  
	  { "type": "Game", "name": "Minecraft", "active": "true", "createdTimestamp":
	  "", "createdBy": { "email": "mail@mail.com", "role": "FREE", "username":
	  "User1", "avatar": "U", "password": "12345" }, "location":{ "lat":1.0,
	  "lon":1.0 } }
	 */

}
