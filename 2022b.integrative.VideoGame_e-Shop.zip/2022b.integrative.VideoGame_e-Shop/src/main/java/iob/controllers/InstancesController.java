package iob.controllers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import iob.InstanceId;
import iob.boundary.InstanceBoundary;
import iob.logic.EnhancedInstancesService;

@RestController
public class InstancesController {
	private EnhancedInstancesService instancesService;

	@Autowired
	public InstancesController(EnhancedInstancesService instancesService) {
		this.instancesService = instancesService;
	}

	// Instance APIS
	@RequestMapping(path = "/iob/instances/{instanceDomain}/{instanceId}", // ?userDomain={domain}&userEmail={email}",
																			// // InstanceBoundry
			method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public InstanceBoundary getSpecificInstance(@PathVariable("instanceDomain") String instanceDomain,
			@PathVariable("instanceId") String instanceId,
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain) {

		return instancesService.getSpecificInstance(instanceDomain, instanceId, userEmail, userDomain);
	}

	@RequestMapping(path = "/iob/instances/search/byName/{name}", // ?userDomain={domain}&userEmail={email}&size={size}&page={page}
			method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public InstanceBoundary[] getSpecificInstanceByName(
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain,
			@PathVariable("name") String name,
			@RequestParam(name = "size", required = false, defaultValue = "10") int size,
			@RequestParam(name = "page", required = false, defaultValue = "0") int page

	) {

		return instancesService.getSpecificInstanceByName(userDomain, userEmail, name, size, page)
				.toArray(new InstanceBoundary[0]);
	}

	@RequestMapping(path = "/iob/instances/search/byType/{type}", // ?userDomain={domain}&userEmail={email}", //
																	// InstanceBoundry
			method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public InstanceBoundary[] getSpecificInstanceByType(
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain,
			@PathVariable("type") String type,
			@RequestParam(name = "size", required = false, defaultValue = "10") int size,
			@RequestParam(name = "page", required = false, defaultValue = "0") int page) {

		return instancesService.getSpecificInstanceByType(userDomain, userEmail, type, size, page).toArray(new InstanceBoundary[0]);
	}

	@RequestMapping(path = "/iob/instances/search/near/{lat}/{lng}/{distance}", // ?userDomain={domain}&userEmail={email}",
			method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public InstanceBoundary[] getSpecificInstanceByLocation(
			@PathVariable("lat") double lat,
			@PathVariable("lng") double lng,
			@PathVariable("distance") double distance,
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain,
			@RequestParam(name = "size", required = false, defaultValue = "10") int size,
			@RequestParam(name = "page", required = false, defaultValue = "0") int page) {

		return instancesService.getSpecificInstanceByLocation(userDomain, userEmail, lat, lng, distance, size, page).toArray(new InstanceBoundary[0]);
	}

	@RequestMapping(path = "/iob/instances", // ?userDomain={domain}&userEmail={email}&size={size}&page={page}
			method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)

	public InstanceBoundary[] getAllInstances(
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain,
			@RequestParam(name = "size", required = false, defaultValue = "10") int size,
			@RequestParam(name = "page", required = false, defaultValue = "0") int page) {
		return instancesService.getAllInstances(userDomain, userEmail, size, page).toArray(new InstanceBoundary[0]);
	}

	@RequestMapping(path = "/iob/instances", // InstanceBoundry
			method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE , 
			consumes = MediaType.APPLICATION_JSON_VALUE)

	public InstanceBoundary createNewInstances(@RequestBody InstanceBoundary instance) {
		instance.setInstanceId(new InstanceId());
		instance.setCreatedTimestamp(new Date());
		return instancesService.createInstance(instance);
	}

	@RequestMapping(path = "/iob/instances/{instanceDomain}/{instanceId}", // InstaceBoundry
			method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)

	public void updateInstanceDetails(
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain,
			@PathVariable("instanceDomain") String instanceDomain, @PathVariable("instanceId") String instanceId,
			@RequestBody InstanceBoundary update) {
		instancesService.updateInstance(instanceDomain, instanceId, userDomain, userEmail, update);
	}

}
