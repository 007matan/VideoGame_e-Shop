package iob.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import iob.boundary.ActivityBoundary;
import iob.boundary.UserBoundary;
import iob.logic.EnhancedActivitiesService;
import iob.logic.EnhancedInstancesService;
import iob.logic.EnhancedUsersService;

@RestController
public class AdminController {
	private EnhancedActivitiesService activitiesService;
	private EnhancedUsersService userService;
	private EnhancedInstancesService instancesService;

	@Autowired
	public AdminController(EnhancedActivitiesService activitiesService, EnhancedUsersService userService,
			EnhancedInstancesService instancesService) {
		super();
		this.activitiesService = activitiesService;
		this.userService = userService;
		this.instancesService = instancesService;
	}

	@RequestMapping(path = "/iob/admin/activities", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)

	public ActivityBoundary[] getAllActivites(
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain,
			@RequestParam(name = "size", required = false, defaultValue = "10") int size,
			@RequestParam(name = "page", required = false, defaultValue = "0") int page) {
		return activitiesService.getAllActivities(userDomain, userEmail, size, page).toArray(new ActivityBoundary[0]);
	}

	@RequestMapping(path = "/iob/admin/users", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)

	public UserBoundary[] getAllUsers(
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain,
			@RequestParam(name = "size", required = false, defaultValue = "10") int size,
			@RequestParam(name = "page", required = false, defaultValue = "0") int page) {
		return userService.getAllUsers(userDomain, userEmail, size, page).toArray(new UserBoundary[0]);
	}

	@RequestMapping(path = "/iob/admin/activities", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)

	public void deleteActivities(
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain) {
		activitiesService.deleteAllActivities(userDomain,userEmail);
	}

	@RequestMapping(path = "/iob/admin/instances", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)

	public void deleteInstances(
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain) {
		instancesService.deleteAllInstances(userDomain,userEmail);
	}

	@RequestMapping(path = "/iob/admin/users", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)

	public void deleteUsers(
			@RequestParam(name = "userEmail", required = false, defaultValue = "mail@mail.com") String userEmail,
			@RequestParam(name = "userDomain", required = false, defaultValue = "2022b.Amit.Levy") String userDomain) {
		userService.deleteAllUsers(userDomain,userEmail);
	}

}
