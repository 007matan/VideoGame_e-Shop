package iob.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import iob.ActivityId;
import iob.boundary.ActivityBoundary;
import iob.logic.EnhancedActivitiesService;

@RestController
public class ActivityController {

	private EnhancedActivitiesService activitiesService;

	@Autowired
	public ActivityController(EnhancedActivitiesService activitiesService) {
		this.activitiesService = activitiesService;
	}

	@RequestMapping(path = "/iob/Activities", // ActivityBoundry
			method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Object invokeAnInstanceActivity(@RequestBody ActivityBoundary newActivityBoundary) {
		newActivityBoundary.setActivityId(new ActivityId());
		return activitiesService.invokeActivity(newActivityBoundary);
	}
}
