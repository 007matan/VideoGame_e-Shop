package iob.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import iob.boundary.NewUserBoundary;
import iob.boundary.UserBoundary;
import iob.logic.EnhancedUsersService;

@RestController
public class UserController {
	private EnhancedUsersService userService;

	@Autowired
	public UserController(EnhancedUsersService userService) {
		this.userService = userService;
	}

	@RequestMapping(path = "/iob/users/login/{userDomain}/{userEmail}", // UserBoundry
			method = RequestMethod.GET, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	
	
	public UserBoundary userID(@PathVariable("userEmail") String email,  @PathVariable("userDomain") String domain ) {
		System.out.println(userService.login(domain, email));
		return userService.login(domain, email);
	}

	@RequestMapping(path = "/iob/users/{userDomain}/{userEmail}", // UserBoundry
			method = RequestMethod.PUT, 
			produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)

	public void updateUserDetails(@PathVariable("userEmail") String email, @PathVariable("userDomain") String domain,
			@RequestBody UserBoundary us) {
		userService.updateUser(domain, email, us);
	}

	@RequestMapping(path = "/iob/users", // NewUserBoundary
			method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)

	public UserBoundary createNewUser(@RequestBody NewUserBoundary newUsr) {
		return userService.createUser(newUsr);
	}

}
