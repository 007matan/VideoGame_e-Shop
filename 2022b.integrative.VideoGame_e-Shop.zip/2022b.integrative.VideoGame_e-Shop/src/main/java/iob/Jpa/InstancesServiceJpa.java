package iob.Jpa;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import iob.UserId;
import iob.boundary.InstanceBoundary;
import iob.converters.InstanceConverter;
import iob.data.InstanceEntity;
import iob.data.UserRole;
import iob.doa.InstancesDao;
import iob.doa.UsersDao;
import iob.logic.EnhancedInstancesService;

@Service
public class InstancesServiceJpa implements EnhancedInstancesService {
	private InstancesDao instancesDao;
	private UsersDao userDao;
	private InstanceConverter converter;
	@Value("${spring.application.name:Default 2022b.Amit.Levy}")
	private String domain;

	@Autowired
	public InstancesServiceJpa(InstancesDao instancesDao, UsersDao userDao, InstanceConverter converter) {
		super();
		this.instancesDao = instancesDao;
		this.userDao = userDao;
		this.converter = converter;
	}

	@Override
	public InstanceBoundary createInstance(InstanceBoundary instance) {
		if (this.userDao.findByuserId(instance.getCreatedBy(), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.MANAGER)){
		System.out.println(instance.toString());
		InstanceEntity entity = converter.toEntity(instance);
		entity = this.instancesDao.save(entity);
		return instance;
				}
				throw new PermissionException("Permission denied for "+instance.getCreatedBy().getUserEmail());
	}

	@Override
	@Deprecated
	public void updateInstance(String instanceDomain, String instanceID, InstanceBoundary update) {
		/*
		 * Optional<InstanceEntity> optional = this.instancesDao.findById(instanceID);
		 * if (optional.isPresent()) { InstanceEntity entity = optional.get(); entity =
		 * converter.toEntity(update); entity = this.instancesDao.save(entity); }
		 */
		// return converter.toBoundary(entity);
		// else
		// return null;// If return null means not found
		throw new RuntimeException("deprecated method");
	}

	@Override
	@Deprecated
	public InstanceBoundary getSpecificInstance(String instanceDomain, String instanceID) {
		/*
		 * Optional<InstanceEntity> optional = this.instancesDao.findById(instanceID);
		 * if (optional.isPresent()) { InstanceEntity entity = optional.get(); return
		 * converter.toBoundary(entity); } else return null;// If return null means not
		 * found
		 */
		throw new RuntimeException("deprecated method");
	}

	@Override
	@Deprecated
	public List<InstanceBoundary> getAllInstances() {
		/*
		 * Iterable<InstanceEntity> iterable = this.instancesDao.findAll();
		 * 
		 * Stream<InstanceEntity> stream = StreamSupport.stream(iterable.spliterator(),
		 * false);
		 * 
		 * return stream.map(converter::toBoundary).collect(Collectors.toList());
		 */
		throw new RuntimeException("deprecated method");
	}

	@Override
	@Deprecated
	public void deleteAllInstances() {
		// this.instancesDao.deleteAll();
		throw new RuntimeException("deprecated method");
	}

	@Override
	public List<InstanceBoundary> getSpecificInstanceByName(String userDomain, String userEmail, String name, int size,
			int page) {
		if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.MANAGER))
			return instancesDao.findInstanceByName(name, PageRequest.of(page, size, Sort.by("name"))).stream()
					.map(this.converter::toBoundary).collect(Collectors.toList());
		else if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.PLAYER)) {
			return instancesDao.findInstanceByName(name, PageRequest.of(page, size, Sort.by("name"))).stream()
					.filter(instance -> instance.getActive()).map(this.converter::toBoundary)
					.collect(Collectors.toList());
		}
		//return null;
		throw new NotFoundException("Instance not found");
	}

	@Override
	public List<InstanceBoundary> getSpecificInstanceByType(String userDomain, String userEmail, String type, int size,
			int page) {
		if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.MANAGER))
			return instancesDao.findInstanceByType(type, PageRequest.of(page, size, Sort.by("type"))).stream()
					.map(this.converter::toBoundary).collect(Collectors.toList());
		else if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.PLAYER)) {
			return instancesDao.findInstanceByType(type, PageRequest.of(page, size, Sort.by("type"))).stream()
					.filter(instance -> instance.getActive()).map(this.converter::toBoundary)
					.collect(Collectors.toList());
		}
		return null;
	}

	@Override
	public List<InstanceBoundary> getSpecificInstanceByLocation(String userDomain, String userEmail, double lat,
			double lon, double distance, int size, int page) {
		if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.MANAGER))
			return instancesDao.findInstanceByLocation(lat, lon, distance, PageRequest.of(page, size, Sort.by("location")))
					.stream().map(this.converter::toBoundary).collect(Collectors.toList());
		else if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.PLAYER)) {
			return instancesDao.findInstanceByLocation(lat, lon, distance, PageRequest.of(page, size, Sort.by("location")))
					.stream().filter(instance -> instance.getActive()).map(this.converter::toBoundary)
					.collect(Collectors.toList());
		}
		return null;
	}

	@Override
	public void updateInstance(String instanceDomain, String instanceID, String userDomain, String userEmail,
			InstanceBoundary update) {
		if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.MANAGER)) {
			Optional<InstanceEntity> optional = this.instancesDao.findById(instanceID);
			if (optional.isPresent()) {
				InstanceEntity entity = optional.get();
				entity = converter.toEntity(update);
				entity = this.instancesDao.save(entity);
			}
		}
		else throw new PermissionException("Permission denied for "+userEmail);

	}

	@Override
	public InstanceBoundary getSpecificInstance(String instanceDomain, String instanceID, String userDomain,
			String userEmail) {

		if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.MANAGER)) {
			Optional<InstanceEntity> optional = this.instancesDao.findById(instanceID);
			if (optional.isPresent()) {
				InstanceEntity entity = optional.get();
				return converter.toBoundary(entity);
			} else
				throw new NotFoundException("user not found" + userEmail);
		} else if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.PLAYER)) {
			Optional<InstanceEntity> optional = this.instancesDao.findById(instanceID);
			if (optional.isPresent()) {
				InstanceEntity entity = optional.get();
				if (entity.getActive())
					return converter.toBoundary(entity);
			} else
				throw new NotFoundException("User not found" + userEmail);
		}
		throw new PermissionException("Permission denied" + userEmail);
	}

	@Override
	public List<InstanceBoundary> getAllInstances(String userDomain, String userEmail, int size, int page) {
		if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.MANAGER))
			return this.instancesDao.findAll(PageRequest.of(page, size, Direction.ASC, "instanceId")).getContent().stream()
					.map(this.converter::toBoundary).collect(Collectors.toList());
		else if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.PLAYER))
			return this.instancesDao.findAll(PageRequest.of(page, size, Direction.ASC, "instanceId")).getContent().stream()
					.filter(instance -> instance.getActive()).map(this.converter::toBoundary)
					.collect(Collectors.toList());
		throw new NotFoundException("Instances not found");
	}

	@Override
	public void deleteAllInstances(String userDomain, String userEmail) {
		if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.ADMIN))
			this.instancesDao.deleteAll();
		 else {
			 throw new PermissionException("Permission denied" + userEmail);
		 }

			 
	}

}
