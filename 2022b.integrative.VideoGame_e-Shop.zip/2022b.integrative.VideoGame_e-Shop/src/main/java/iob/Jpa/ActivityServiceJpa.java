package iob.Jpa;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import iob.ActivityId;
import iob.UserId;
import iob.boundary.ActivityBoundary;
import iob.converters.ActivityConverter;
import iob.data.ActivityEntity;
import iob.data.UserRole;
import iob.doa.ActivitiesDao;
import iob.doa.InstancesDao;
import iob.doa.UsersDao;
import iob.logic.EnhancedActivitiesService;

@Service
public class ActivityServiceJpa implements EnhancedActivitiesService {
	private ActivitiesDao activitiesDao;
	private UsersDao userDao;
	private InstancesDao instancesDao;
	private ActivityConverter converter;

	@Autowired
	public ActivityServiceJpa(ActivitiesDao activitiesDao, UsersDao userDao, InstancesDao instancesDao,
			ActivityConverter converter) {
		super();
		this.activitiesDao = activitiesDao;
		this.userDao = userDao;
		this.instancesDao = instancesDao;
		this.converter = converter;
	}

	@Override
	public Object invokeActivity(ActivityBoundary activity) {
		activity.setActivityId(new ActivityId());
		if (this.userDao.findByuserId(activity.getInvokedBy(), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.PLAYER)
				&& this.instancesDao.findById(activity.getInstanceId().getId()).get().getActive()) {
			activity.setCreatedTimestamp(new Date());
			ActivityEntity entity = converter.toEntity(activity);
			entity = this.activitiesDao.save(entity);
			return activity;
		}
		throw new PermissionException("Permission denied: " + activity.getInvokedBy().getUserEmail());
	}

	@Override
	@Deprecated
	public List<ActivityBoundary> getAllActivities() {
		/*
		 * Iterable<ActivityEntity> iterable = this.activitiesDao.findAll();
		 * 
		 * 
		 * Stream<ActivityEntity> stream = StreamSupport.stream(iterable.spliterator(),
		 * false);
		 * 
		 * return stream.map(converter::toBoundary).collect(Collectors.toList());
		 */
		throw new RuntimeException("deprecated method");

	}

	@Override
	@Deprecated
	public void deleteAllActivities() {
		// this.activitiesDao.deleteAll();
		throw new RuntimeException("deprecated method");
	}

	@Override
	public List<ActivityBoundary> getAllActivities(String userDomain, String userEmail, int size, int page) {
		if (this.userDao.findByuserId(new UserId(userEmail),  PageRequest.of(page, size, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.ADMIN)) {
			return this.activitiesDao.findAll(PageRequest.of(page, size, Direction.ASC, "id")).getContent().stream() 
					.map(this.converter::toBoundary).collect(Collectors.toList());
		}
		throw new PermissionException("Permission denied: " + userEmail);
	}

	@Override
	public void deleteAllActivities(String userDomain, String userEmail) {
		if (this.userDao.findByuserId(new UserId(userEmail),  PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.ADMIN))
			this.activitiesDao.deleteAll();
		else {
			throw new PermissionException("Permission denied: " + userEmail);
		}
	}

}
