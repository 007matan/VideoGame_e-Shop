package iob.Jpa;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import iob.UserId;
import iob.boundary.NewUserBoundary;
import iob.boundary.UserBoundary;
import iob.converters.UserConverter;
import iob.data.UserEntity;
import iob.data.UserRole;
import iob.doa.UsersDao;
import iob.logic.EnhancedUsersService;

@Service
public class UsersServiceJpa implements EnhancedUsersService {
	private UsersDao userDao;
	private UserConverter converter;
	@Value("${spring.application.name:Default 2022b.Amit.Levy}")
	private String domain;

	@Autowired
	public UsersServiceJpa(UsersDao userDao, UserConverter userConverter) {
		super();
		this.userDao = userDao;
		this.converter = userConverter;
	}

	@Override
	public UserBoundary createUser(NewUserBoundary user) {
		UserBoundary tempUser = converter.toUserBoundary(user);
		UserEntity entity = converter.toEntity(tempUser);
		entity = this.userDao.save(entity);
		return tempUser;
	}

	@Override
	public UserBoundary login(String userDomain, String userEmail) {
		List<UserEntity> optional = this.userDao.findByuserId(new UserId(userEmail) , PageRequest.of(0, 1 , Direction.DESC , "userId"));
		System.out.println(optional.toString());
		if (optional.size() > 0) {
			UserEntity entity = optional.get(0);
			return converter.toBoundary(entity);
		} 
		throw new NotFoundException("User not found");
	}

	@Override
	public UserBoundary updateUser(String userDomain, String userEmail, UserBoundary update) {
		List<UserEntity> optional = this.userDao.findByuserId(new UserId(userEmail) , PageRequest.of(0, 1 , Direction.DESC , "userId"));
		if (optional.size() > 0) {
			UserEntity entity = optional.get(0);
			System.out.println("Update:" +update);
			entity = converter.toEntity(update);
			entity = this.userDao.save(entity);
			return converter.toBoundary(entity);
		} else
			throw new NotFoundException("User not Found " + userEmail);
	}

	@Deprecated
	@Override
	public List<UserBoundary> getAllUsers() {
		Iterable<UserEntity> iterable = this.userDao.findAll();
		Stream<UserEntity> stream = StreamSupport.stream(iterable.spliterator(), false);
		return stream.map(converter::toBoundary).collect(Collectors.toList());
	}

	@Override
	@Deprecated
	public void deleteAllUsers() {
		//this.userDao.deleteAll();
		throw new RuntimeException("deprecated method");
	}

	@Override
	public void deleteAllUsers(String userDomain, String userEmail) {
		if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.ADMIN)) {
				this.userDao
				.deleteAll();
		}
		throw new PermissionException("Permission denied for "+userEmail);
	}

	@Override
	public List<UserBoundary> getAllUsers(String userDomain, String userEmail, int size, int page) {
		System.out.println(userEmail);
		if (this.userDao.findByuserId(new UserId(userEmail), PageRequest.of(0, 1, Direction.DESC, "userId")).get(0)
				.getRole().equals(UserRole.ADMIN)) {
		return  this.userDao
				.findAll(PageRequest.of(page, size, Direction.ASC,"userId"))
				.getContent()
				.stream()
				.map(this.converter::toBoundary)
				.collect(Collectors.toList());
		}
		throw new PermissionException("Permission denied for "+userEmail);
	}

}
