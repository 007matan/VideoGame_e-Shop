package iob;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;

public class ActivityId {
	@Value("${spring.application.name:Default 2022b.Amit.Levy}")
	private String domain = "2022b.Amit.Levy";
	private String id;
	
	public ActivityId() {
		this.id = UUID.randomUUID().toString();
	}

	public ActivityId(String activityId) {
		this.id = activityId;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
